import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_en.dart';
import 'app_localizations_vi.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'gen_l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale) : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates = <LocalizationsDelegate<dynamic>>[
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('en'),
    Locale('vi')
  ];

  /// No description provided for @appTitle.
  ///
  /// In en, this message translates to:
  /// **'Rainy Night'**
  String get appTitle;

  /// No description provided for @findPerfectSound.
  ///
  /// In en, this message translates to:
  /// **'Find your perfect sleep sound'**
  String get findPerfectSound;

  /// No description provided for @newReleases.
  ///
  /// In en, this message translates to:
  /// **'New Releases'**
  String get newReleases;

  /// No description provided for @noSoundsAvailable.
  ///
  /// In en, this message translates to:
  /// **'No sounds available'**
  String get noSoundsAvailable;

  /// No description provided for @failedToLoadSounds.
  ///
  /// In en, this message translates to:
  /// **'Failed to load sounds'**
  String get failedToLoadSounds;

  /// No description provided for @search.
  ///
  /// In en, this message translates to:
  /// **'Search'**
  String get search;

  /// No description provided for @tapToPlay.
  ///
  /// In en, this message translates to:
  /// **'Tap to play'**
  String get tapToPlay;

  /// No description provided for @soundGentleRain.
  ///
  /// In en, this message translates to:
  /// **'Gentle Rain'**
  String get soundGentleRain;

  /// No description provided for @soundGentleRainDesc.
  ///
  /// In en, this message translates to:
  /// **'Soft, calming raindrops creating a peaceful atmosphere for relaxation and sleep'**
  String get soundGentleRainDesc;

  /// No description provided for @soundHeavyRain.
  ///
  /// In en, this message translates to:
  /// **'Heavy Rainfall'**
  String get soundHeavyRain;

  /// No description provided for @soundHeavyRainDesc.
  ///
  /// In en, this message translates to:
  /// **'Intense rain shower with deep, resonant drops perfect for deep sleep'**
  String get soundHeavyRainDesc;

  /// No description provided for @soundThunderRain.
  ///
  /// In en, this message translates to:
  /// **'Thunder & Rain'**
  String get soundThunderRain;

  /// No description provided for @soundThunderRainDesc.
  ///
  /// In en, this message translates to:
  /// **'Distant thunder accompanied by steady rainfall, creating a dramatic yet soothing ambiance'**
  String get soundThunderRainDesc;

  /// No description provided for @soundWindyRain.
  ///
  /// In en, this message translates to:
  /// **'Windy Rain'**
  String get soundWindyRain;

  /// No description provided for @soundWindyRainDesc.
  ///
  /// In en, this message translates to:
  /// **'Gentle breeze with light rain, perfect for a cozy night\'s sleep'**
  String get soundWindyRainDesc;

  /// No description provided for @soundThunderstorm.
  ///
  /// In en, this message translates to:
  /// **'Thunderstorm'**
  String get soundThunderstorm;

  /// No description provided for @soundThunderstormDesc.
  ///
  /// In en, this message translates to:
  /// **'Powerful storm with thunder and heavy rain, creating an immersive sleep environment'**
  String get soundThunderstormDesc;

  /// No description provided for @soundRainOnRoof.
  ///
  /// In en, this message translates to:
  /// **'Rain on Roof'**
  String get soundRainOnRoof;

  /// No description provided for @soundRainOnRoofDesc.
  ///
  /// In en, this message translates to:
  /// **'Soothing sound of raindrops falling on a wooden roof, perfect for relaxation'**
  String get soundRainOnRoofDesc;

  /// No description provided for @stopAudioIn.
  ///
  /// In en, this message translates to:
  /// **'Stop audio in'**
  String get stopAudioIn;

  /// No description provided for @minutes.
  ///
  /// In en, this message translates to:
  /// **'{minutes} minutes'**
  String minutes(Object minutes);

  /// No description provided for @minutesOnly.
  ///
  /// In en, this message translates to:
  /// **'{minutes} minutes'**
  String minutesOnly(Object minutes);

  /// No description provided for @hoursOnly.
  ///
  /// In en, this message translates to:
  /// **'{hours} hour'**
  String hoursOnly(Object hours);

  /// No description provided for @hoursAndMinutes.
  ///
  /// In en, this message translates to:
  /// **'{hours} hour {minutes} minutes'**
  String hoursAndMinutes(Object hours, Object minutes);

  /// No description provided for @cancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get cancel;

  /// No description provided for @playing.
  ///
  /// In en, this message translates to:
  /// **'Playing'**
  String get playing;
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) => <String>['en', 'vi'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {


  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'en': return AppLocalizationsEn();
    case 'vi': return AppLocalizationsVi();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.'
  );
}
