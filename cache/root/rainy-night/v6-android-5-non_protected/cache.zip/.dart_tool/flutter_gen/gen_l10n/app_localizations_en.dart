// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appTitle => 'Rainy Night';

  @override
  String get findPerfectSound => 'Find your perfect sleep sound';

  @override
  String get newReleases => 'New Releases';

  @override
  String get noSoundsAvailable => 'No sounds available';

  @override
  String get failedToLoadSounds => 'Failed to load sounds';

  @override
  String get search => 'Search';

  @override
  String get tapToPlay => 'Tap to play';

  @override
  String get soundGentleRain => 'Gentle Rain';

  @override
  String get soundGentleRainDesc => 'Soft, calming raindrops creating a peaceful atmosphere for relaxation and sleep';

  @override
  String get soundHeavyRain => 'Heavy Rainfall';

  @override
  String get soundHeavyRainDesc => 'Intense rain shower with deep, resonant drops perfect for deep sleep';

  @override
  String get soundThunderRain => 'Thunder & Rain';

  @override
  String get soundThunderRainDesc => 'Distant thunder accompanied by steady rainfall, creating a dramatic yet soothing ambiance';

  @override
  String get soundWindyRain => 'Windy Rain';

  @override
  String get soundWindyRainDesc => 'Gentle breeze with light rain, perfect for a cozy night\'s sleep';

  @override
  String get soundThunderstorm => 'Thunderstorm';

  @override
  String get soundThunderstormDesc => 'Powerful storm with thunder and heavy rain, creating an immersive sleep environment';

  @override
  String get soundRainOnRoof => 'Rain on Roof';

  @override
  String get soundRainOnRoofDesc => 'Soothing sound of raindrops falling on a wooden roof, perfect for relaxation';

  @override
  String get stopAudioIn => 'Stop audio in';

  @override
  String minutes(Object minutes) {
    return '$minutes minutes';
  }

  @override
  String minutesOnly(Object minutes) {
    return '$minutes minutes';
  }

  @override
  String hoursOnly(Object hours) {
    return '$hours hour';
  }

  @override
  String hoursAndMinutes(Object hours, Object minutes) {
    return '$hours hour $minutes minutes';
  }

  @override
  String get cancel => 'Cancel';

  @override
  String get playing => 'Playing';
}
