// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Vietnamese (`vi`).
class AppLocalizationsVi extends AppLocalizations {
  AppLocalizationsVi([String locale = 'vi']) : super(locale);

  @override
  String get appTitle => 'Đêm Mưa';

  @override
  String get findPerfectSound => 'Tìm âm thanh ngủ hoàn hảo cho bạn';

  @override
  String get newReleases => 'Mới Phát Hành';

  @override
  String get noSoundsAvailable => 'Không có âm thanh nào';

  @override
  String get failedToLoadSounds => 'Không thể tải âm thanh';

  @override
  String get search => 'Tìm kiếm';

  @override
  String get tapToPlay => 'Bắt đầu';

  @override
  String get soundGentleRain => 'Mưa Nhẹ';

  @override
  String get soundGentleRainDesc => 'Tiếng mưa nhẹ nhàng tạo không gian yên bình cho giấc ngủ và thư giãn';

  @override
  String get soundHeavyRain => 'Mưa Rào';

  @override
  String get soundHeavyRainDesc => 'Cơn mưa rào mạnh mẽ với những giọt mưa sâu lắng, hoàn hảo cho giấc ngủ sâu';

  @override
  String get soundThunderRain => 'Mưa & Sấm';

  @override
  String get soundThunderRainDesc => 'Tiếng sấm xa xa kết hợp với mưa rơi đều đặn, tạo không gian ấn tượng nhưng vẫn êm dịu';

  @override
  String get soundWindyRain => 'Mưa & Gió';

  @override
  String get soundWindyRainDesc => 'Gió nhẹ kết hợp với mưa nhẹ, hoàn hảo cho một đêm ngủ ấm áp';

  @override
  String get soundThunderstorm => 'Bão Sấm';

  @override
  String get soundThunderstormDesc => 'Cơn bão mạnh mẽ với sấm sét và mưa lớn, tạo môi trường ngủ chìm đắm';

  @override
  String get soundRainOnRoof => 'Mưa Rơi Trên Mái';

  @override
  String get soundRainOnRoofDesc => 'Âm thanh êm dịu của những giọt mưa rơi trên mái nhà, hoàn hảo cho thư giãn';

  @override
  String get stopAudioIn => 'Hẹn giờ tắt sau';

  @override
  String minutes(Object minutes) {
    return '$minutes phút';
  }

  @override
  String minutesOnly(Object minutes) {
    return '$minutes phút';
  }

  @override
  String hoursOnly(Object hours) {
    return '$hours giờ';
  }

  @override
  String hoursAndMinutes(Object hours, Object minutes) {
    return '$hours giờ $minutes phút';
  }

  @override
  String get cancel => 'Hủy';

  @override
  String get playing => 'Đang phát';
}
